"""
core.py
Main logic: the Member class (OOP) and functions that process
the raw member list, including functional-programming examples.
"""

from .utils import clean_string, validate_email, validate_phone, InvalidMemberDataError


class Member:
    """Represents a single, validated member profile."""

    def __init__(self, name, email, phone):
        self.name = clean_string(name)
        self.email = validate_email(email)
        self.phone = validate_phone(phone)

    def __repr__(self):
        return f"Member(name='{self.name}', email='{self.email}', phone='{self.phone}')"

    def __str__(self):
        return f"{self.name} <{self.email}> ({self.phone})"


def process_raw_members(raw_members):
    """
    Validates/cleans each raw dict, returns a list of Member objects.
    Bad records are skipped, not fatal, using try/except.
    """
    members = []
    for raw in raw_members:
        name_for_log = raw.get("name", "Unknown")
        print(f"Processing member: {name_for_log}...", end=" ")
        try:
            member = Member(raw.get("name"), raw.get("email"), raw.get("phone"))
            members.append(member)
            print("Validation Successful.")
        except InvalidMemberDataError as e:
            print(f"Skipping.\nError: {e}")
        except (KeyError, ValueError) as e:
            print(f"Skipping.\nStandard error: {e}")

    print(f"Summary: {len(members)} members processed successfully.")
    return members


def filter_members_by_domain(members, domain):
    """Return members whose email ends with the given domain."""
    return list(filter(lambda m: m.email.endswith(domain), members))


def get_all_names(members):
    """Return a list of just the members' names."""
    return list(map(lambda m: m.name, members))