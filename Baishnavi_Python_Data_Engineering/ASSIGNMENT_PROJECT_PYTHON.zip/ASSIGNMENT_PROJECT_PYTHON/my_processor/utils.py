"""
utils.py
Helper logic: regex validation and string-cleaning utilities,
plus the custom exception used across the package.
"""

import re

class InvalidMemberDataError(Exception):
    """Raised when a member record contains malformed data
    (bad name, email, or phone number)."""
    pass


EMAIL_PATTERN = re.compile(r'^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$')
PHONE_PATTERN = re.compile(r'^\d{3}-\d{4}$')


def clean_string(value):
    """Clean a raw string using slicing/strip."""
    if not isinstance(value, str):
        raise InvalidMemberDataError(f"Expected a string, got {type(value).__name__}")
    cleaned = value[:].strip()
    if not cleaned:
        raise InvalidMemberDataError("Value cannot be empty after cleaning.")
    return cleaned


def validate_email(email):
    """Validate an email address using the re module."""
    email = clean_string(email)
    if not EMAIL_PATTERN.match(email):
        raise InvalidMemberDataError(f"Invalid email for member: '{email}'")
    return email


def validate_phone(phone):
    """Validate a phone number using the re module."""
    phone = clean_string(phone)
    if not PHONE_PATTERN.match(phone):
        raise InvalidMemberDataError(f"Invalid phone number: '{phone}'")
    return phone